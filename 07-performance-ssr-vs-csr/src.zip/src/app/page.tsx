// 07-performance-ssr-vs-csr/src/app/page.tsx

export default function Home() {
  return <div>Home</div>;
}
