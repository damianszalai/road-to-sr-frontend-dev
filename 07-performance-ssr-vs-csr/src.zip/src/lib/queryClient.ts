// 07-performance-ssr-vs-csr/src/lib/queryClient.ts
import { QueryClient } from '@tanstack/react-query';
export const getQueryClient = () => new QueryClient();
