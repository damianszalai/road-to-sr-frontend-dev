// 06-event-registration/src/types/registrations.ts
export interface Registrations {
  id: string;
  event_id: string;
  user_id: string;
  created_at: string;
}
